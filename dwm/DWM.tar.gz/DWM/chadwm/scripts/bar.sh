#!/bin/bash 

# ^c$var^ = fg color
# ^b$var^ = bg color

interval=0

# load colors
. ~/.config/chadwm/scripts/bar_themes/onedark


battery() {
	get_capacity=$(acpi | awk -F"[: ,]*" 'NR==1{ gsub("%", "");print $4}')
	state=$(acpi | awk -F"[: ,]*" 'NR==1{ gsub("%", "");print $3}')
	if [[ "${state}" == "Discharging" ]]
	then
		if [[ $get_capacity == 100 ]]
		then
			printf "^c$black^^b$darkblue^  ^c$red^^b$blue^ ${get_capacity}"
		elif [[ $get_capacity -ge 85 && $get_capacity -lt 100 ]]
		then
			printf "^c$black^^b$darkblue^  ^c$red^^b$blue^ ${get_capacity}"
		elif [[ $get_capacity -ge 65 && $get_capacity -lt 85 ]]
		then
			printf "^c$black^^b$darkblue^^b$darkblue^  ^c$red^^b$blue^ ${get_capacity}"
		elif [[ $get_capacity -ge 35 && $get_capacity -lt 65 ]]
		then 
			printf "^c$black^^b$darkblue^^b$darkblue^  ^c$red^^b$blue^ ${get_capacity}"
		elif [[ $get_capacity -ge 10 && $get_capacity -lt 35 ]]
		then 
			printf "^c$black^^b$darkblue^^b$darkblue^  ^c$red^^b$blue^ ${get_capacity}"
		elif [[ $get_capacity -ge 0 && $get_capacity -lt 10 ]]
		then 
			printf "^c$black^^b$darkblue^  ^c$red^^b$blue^ ${get_capacity}"
		fi
	else
		if [[ $get_capacity == 100 ]]
		then
			printf "^c$black^^b$darkblue^  ^c$red^^b$blue^ ${get_capacity}"
		elif [[ $get_capacity -ge 85 && $get_capacity -lt 100 ]]
		then
			printf "^c$black^^b$darkblue^  ^c$red^^b$blue^ ${get_capacity}"
		elif [[ $get_capacity -ge 65 && $get_capacity -lt 85 ]]
		then
			printf "^c$black^^b$darkblue^  ^c$red^^b$blue^${get_capacity}"
		elif [[ $get_capacity -ge 35 && $get_capacity -lt 65 ]]
		then 
			printf "^c$black^^b$darkblue^  ^c$red^^b$blue^${get_capacity}"
		elif [[ $get_capacity -ge 10 && $get_capacity -lt 35 ]]
		then 
			printf "^c$black^^b$darkblue^  ^c$red^^b$blue^${get_capacity}"
		elif [[ $get_capacity -ge 0 && $get_capacity -lt 10 ]]
		then 
			printf "^c$black^^b$darkblue^  ^c$red^^b$blue^${get_capacity}"
		fi
	fi
}

brightness() {
	printf "^c$black^^b$darkblue^  "
	printf "^c$black^^b$blue^ %.0f" $(cat /sys/class/backlight/nvidia_0/brightness)
}

mem() {
	printf "^c$blue^^b$black^  "
	printf "^c$blue^ $(free -h | awk '/^Mem/ { print $3 }' | sed s/i//g)"
}

wlan() {
	# wifilist_origin=$(nmcli dev wifi | awk -F"[ ]*" '$3!~/SSID/{print $3}')
	# wifilists=($wifilist_origin)
	# # for i in ${wifilists[@]};do
	# # 	printf "%s " $i
	# # done

	activewifi=$(nmcli dev wifi | awk -F"[ ]*" '$0~/*/{print $3}')
	case "$(cat /sys/class/net/wl*/operstate 2>/dev/null)" in
	up) printf "^c$black^ ^b$darkblue^ 󰤨 ^d^%s" "^b$blue^^c$black^ ${activewifi}" ;;
	down) printf "^c$black^ ^b$blue^ 󰤭 ^d^%s" " c$blue^NO" ;;
	esac
}

clock() {
	printf "^c$black^ ^b$darkblue^ 󱑆 "
	printf "^c$black^^b$blue^ $(date '+%R') "
}

sounds() {
	sound=$(amixer sget Master | awk -F "[][]" '$0~/[][]/{ gsub("%", "", $2);print $2 }')
	if [[ $sound == 100 ]]
	then
		printf "^c$black^^b$darkblue^  ^c$red^^b$blue^ %s" ${sound}
	elif [[ $sound -ge 80 && $sound -lt 90 ]]
	then
		printf "^c$black^^b$darkblue^  ^c$red^^b$blue^ %s" ${sound}
	elif [[ $sound -ge 55 && $sound -lt 70 ]]
	then
		printf "^c$black^^b$darkblue^  ^c$red^^b$blue^ %s" ${sound}
	elif [[ $sound -ge 45 && $sound -lt 70 ]]
	then 
		printf "^c$black^^b$darkblue^  ^c$red^^b$blue^ %s" ${sound}
	elif [[ $sound -ge 25 && $sound -lt 45 ]]
	then 
		printf "^c$black^^b$darkblue^  ^c$red^^b$blue^ %s" ${sound}
    elif [[ $sound -ge 0 && $sound -lt 25 ]]
	then 
		printf "^c$black^^b$darkblue^  ^c$red^^b$blue^ %s" ${sound}
	fi
			
}
volumes() {
	volume=$(amixer sget Capture | awk -F "[][]" 'NR==5{ gsub("%", "", $2);print $2 }')
	state=$(amixer sget Capture | awk -F "[][]" 'NR==5{ gsub("%", "", $2);print $6 }')
	if [[ "${state}" == "off" ]]
	then
		printf "^c$black^^b$darkblue^   ^c$red^^b$blue^ %d" 0
	else
		printf "^c$black^^b$darkblue^   ^c$red^^b$blue^ %d" ${volume}
	fi	
}
while true; do

	[ $interval = 0 ] || [ $(($interval % 3600)) = 0 ]
	interval=$((interval + 1))

	sleep 1 && xsetroot -name "$(sounds) $(volumes) $(battery) $(wlan) $(clock)"
done

.
